# Simple Dynamic Strings

## Project Description

An API in ATS for
[simple dynamic strings](https://github.com/antirez/sds)
by Salvatore Sanfilippo.

## The End of [README.md]

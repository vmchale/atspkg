######
#
# HX-2014-11:
# for Perl code translated from ATS
#
######

######
#beg of [bool_cats.pl]
######

############################################

sub
ats2plpre_neg_bool0($) { return !($_[0]); }
sub
ats2plpre_neg_bool1($) { return !($_[0]); }

############################################

######
1; #note that it is needed by 'use' or 'require'
######

######
#end of [bool_cats.pl]
######


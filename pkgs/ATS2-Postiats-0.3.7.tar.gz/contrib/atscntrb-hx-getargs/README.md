# Atscntr-hx-getargs

A simple package to facilitate building command-line support for
utilities.

## Description

### SATS Files

* [getargs.sats](https://github.com/githwxi/ATS-Postiats/tree/master/contrib/atscntrb-hx-getargs/SATS/getargs.sats)
    
### DATS Files

* [getargs.dats](https://github.com/githwxi/ATS-Postiats/tree/master/contrib/atscntrb-hx-getargs/DATS/getargs.dats)

### TEST Files

The files in the TEST directory contain examples that make typical use
of the pakcage.



######
#
# HX-2014-08:
# for Python code translated from ATS
#
######

######
#beg of [char_cats.py]
######

############################################

###### end of [char_cats.py] ######
